var i = 0;
var txt = "Usman Akram"  ;

var speed = 80;

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}

var i = 0;
var Txt = "Web Developer";
var speed = 80;
function typeWriter() {
  if (i < Txt.length) {
    document.getElementById("demo").innerHTML += Txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}



$(document).ready(function(){
    $("").load(function(){
      $("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(3000);
    });
  });

  $(document).ready(function(){
    $(".btn-3").click(function(){
      $("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(3000);
    });
  });


  $(document).ready(function(){
    $("#h1").mouseover(function(){
      alert("Enter Your Personal Information");
    });
  });




